<?php
// Redirect to main website
header("Location: fonend/index.php");
exit;
?>
