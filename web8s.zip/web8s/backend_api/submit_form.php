<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once 'db_config.php'; // Kết nối CSDL

$data = json_decode(file_get_contents("php://input"), true);

if (!empty($data['ho_ten']) && !empty($data['sdt'])) {
    $ho_ten = $data['ho_ten'];
    $nam_sinh = $data['nam_sinh'] ?? '';
    $dia_chi = $data['dia_chi'] ?? '';
    $chuong_trinh = $data['chuong_trinh'] ?? '';
    $quoc_gia = $data['quoc_gia'] ?? '';
    $sdt = $data['sdt'];

    // Lưu vào bảng registrations
    $sql = "INSERT INTO registrations (ho_ten, nam_sinh, dia_chi, chuong_trinh, quoc_gia, sdt) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $ho_ten, $nam_sinh, $dia_chi, $chuong_trinh, $quoc_gia, $sdt);

    if ($stmt->execute()) {
        echo json_encode(["status" => true, "message" => "Đăng ký thành công! Chúng tôi sẽ liên hệ sớm."]);
    } else {
        echo json_encode(["status" => false, "message" => "Lỗi lưu dữ liệu: " . $conn->error]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Vui lòng nhập Họ tên và SĐT"]);
}
$conn->close();
?>