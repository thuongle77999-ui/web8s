<?php
// File: backend_api/db_config.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_nhanluc"; // <-- ĐÃ SỬA: Chuyển từ db_nhanluc thành web8s_db

$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>