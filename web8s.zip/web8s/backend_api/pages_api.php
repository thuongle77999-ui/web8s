<?php
// 1. Tắt hiển thị lỗi HTML của PHP (để không bị lỗi "Unexpected token <")
error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Origin: *");

include 'db_connect.php';

$method = $_SERVER['REQUEST_METHOD'];

// --- PHẦN 1: LẤY DỮ LIỆU (GET) ---
if ($method == 'GET') {
    $sql = "SELECT * FROM site_settings";
    
    // Thêm @ để chặn Warning nếu bảng chưa có
    $result = @$conn->query($sql);

    // KIỂM TRA LỖI: Nếu không lấy được dữ liệu
    if (!$result) {
        // Trả về JSON báo lỗi rõ ràng để bạn biết tại sao
        // $conn->error sẽ cho biết lý do cụ thể (VD: Table doesn't exist)
        echo json_encode([
            "status" => false, 
            "message" => "Lỗi truy vấn SQL: " . $conn->error
        ]);
        exit();
    }

    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[$row['setting_key']] = $row['setting_value'];
        }
    }
    // Trả về dữ liệu sạch
    echo json_encode($data);
    
    $conn->close();
    exit();
}

// --- PHẦN 2: LƯU DỮ LIỆU (POST) ---
if ($method == 'POST') {
    $inputData = json_decode(file_get_contents("php://input"), true);

    if (!empty($inputData)) {
        $stmt = $conn->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        
        if (!$stmt) {
             echo json_encode(["status" => false, "message" => "Lỗi chuẩn bị SQL: " . $conn->error]);
             exit();
        }

        $successCount = 0;
        foreach ($inputData as $key => $value) {
            $safeKey = htmlspecialchars(strip_tags($key));
            $safeValue = $value; 
            $stmt->bind_param("sss", $safeKey, $safeValue, $safeValue);
            if ($stmt->execute()) {
                $successCount++;
            }
        }
        $stmt->close();
        echo json_encode(["status" => true, "message" => "Lưu thành công! (" . $successCount . " mục)"]);
    } else {
        echo json_encode(["status" => false, "message" => "Không có dữ liệu gửi lên."]);
    }
    
    $conn->close();
    exit();
}
?>