<?php
error_reporting(0); // Tắt lỗi rác

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "web8s"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => false, "message" => "Lỗi kết nối: " . $conn->connect_error]));
}
$conn->set_charset("utf8mb4");
?>