document.addEventListener("DOMContentLoaded", function () {
    /* ============================================= */
  
    const API_URL_PAGES = '/web8s/backend_api/pages_api.php'; 

    async function loadGeneralInfo() {
        try {
            const response = await fetch(API_URL_PAGES);
            const data = await response.json();

            // 1. Cập nhật Hotline (Header & Footer)
            if (data.hotline) {
                if(document.getElementById('hien_thi_hotline')) document.getElementById('hien_thi_hotline').innerText = data.hotline;
                if(document.getElementById('hien_thi_hotline_footer')) document.getElementById('hien_thi_hotline_footer').innerText = data.hotline;
            }

            // 2. Cập nhật Tên Website/Công ty
            if (data.site_title) {
                document.title = data.site_title;
                if(document.getElementById('hien_thi_ten_web')) document.getElementById('hien_thi_ten_web').innerText = data.site_title;
            }

            // 3. Cập nhật Địa chỉ
            if (data.contact_address && document.getElementById('hien_thi_dia_chi_footer')) {
                document.getElementById('hien_thi_dia_chi_footer').innerText = data.contact_address;
            }

            // 4. Cập nhật Email
            if (data.email && document.getElementById('hien_thi_email')) {
                document.getElementById('hien_thi_email').innerText = data.email;
            }

            // 5. Cập nhật Bản đồ (Google Map)
            if (data.contact_map && data.contact_map.trim() !== "" && document.getElementById('hien_thi_map')) {
                document.getElementById('hien_thi_map').innerHTML = data.contact_map;
                const ifr = document.querySelector('#hien_thi_map iframe');
                if(ifr) {
                    ifr.style.width = "100%";
                    ifr.style.height = "200px";
                    ifr.style.border = "none";
                    ifr.style.borderRadius = "5px";
                }
            }
        } catch (error) {
            console.warn("Chưa đồng bộ được Footer từ Admin:", error);
        }
    }
    loadGeneralInfo();

    /* ========================== */
    /* 1. XỬ LÝ SLIDER (BANNER)   */
    /* ========================== */
    const slider = document.querySelector(".slider");
    const images = document.querySelectorAll(".slider img");
    const nextBtn = document.querySelector(".next");
    const prevBtn = document.querySelector(".prev");

    if (slider && images.length > 0) {
        let index = 0;
        let slideInterval;

        const updateSlider = () => {
            slider.style.transform = `translateX(-${index * 100}%)`;
        };

        const startSlideTimer = () => {
            if (slideInterval) clearInterval(slideInterval);
            slideInterval = setInterval(() => {
                index++;
                if (index >= images.length) index = 0;
                updateSlider();
            }, 4000);
        };

        if (nextBtn) {
            nextBtn.onclick = () => {
                index++;
                if (index >= images.length) index = 0;
                updateSlider();
                startSlideTimer();
            };
        }

        if (prevBtn) {
            prevBtn.onclick = () => {
                index--;
                if (index < 0) index = images.length - 1;
                updateSlider();
                startSlideTimer();
            };
        }
        startSlideTimer();
    }

    /* ========================== */
    /* 2. HIỆN Ô NHẬP QUỐC GIA KHÁC */
    /* ========================== */
    const quocGiaSelect = document.getElementById("quoc_gia");
    const quocGiaKhacBox = document.getElementById("quoc_gia_khac_box");

    if (quocGiaSelect && quocGiaKhacBox) {
        quocGiaSelect.addEventListener("change", function () {
            quocGiaKhacBox.style.display = (this.value === "Khác") ? "block" : "none";
        });
    }

    /* ========================== */
    /* 3. SCROLL MƯỢT ĐẾN FORM    */
    /* ========================== */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    /* ========================== */
    /* 4. VALIDATE DỮ LIỆU NHẬP   */
    /* ========================== */
    const hoTenInput = document.getElementById("ho_ten");
    if (hoTenInput) {
        hoTenInput.addEventListener("input", function () {
            let start = this.selectionStart;
            let value = this.value;
            value = value.replace(/[^\p{L}\s]/gu, "");
            value = value.replace(/\s{2,}/g, " ");
            value = value.replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); });
            this.value = value;
            this.setSelectionRange(start, start);
        });
    }

    const namSinhInput = document.getElementById("nam_sinh");
    if (namSinhInput) {
        namSinhInput.addEventListener("input", function () {
            this.value = this.value.replace(/[^0-9]/g, ""); 
        });
        namSinhInput.addEventListener("blur", function () { 
            let year = parseInt(this.value);
            const currentYear = new Date().getFullYear();
            if (!isNaN(year) && this.value.length === 4) {
                if (year > currentYear) this.value = currentYear; 
                if (year < 1900) this.value = 1900; 
            }
        });
    }

    const sdtInput = document.getElementById("sdt");
    if (sdtInput) {
        sdtInput.addEventListener("input", function () {
            this.value = this.value.replace(/[^0-9]/g, "").substring(0, 11);
        });
    }

    /* ========================== */
    /* 5. GỬI FORM (AJAX)         */
    /* ========================== */
    const form = document.getElementById('userRegistrationForm');
    if (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            const messageDisplay = document.getElementById('message');
            if (messageDisplay) {
                messageDisplay.textContent = '⏳ Đang gửi thông tin...';
                messageDisplay.style.color = '#0f75bd';
            }

            let selectedQuocGia = document.getElementById('quoc_gia').value;
            const quocGiaKhacInput = document.getElementById('quoc_gia_khac');
            
            if (selectedQuocGia === "Khác") {
                const customVal = quocGiaKhacInput ? quocGiaKhacInput.value.trim() : "";
                if(customVal !== "") {
                    selectedQuocGia = customVal;
                } else {
                    if(messageDisplay) {
                        messageDisplay.textContent = '❌ Vui lòng nhập tên quốc gia mong muốn.';
                        messageDisplay.style.color = 'red';
                    }
                    if(quocGiaKhacInput) quocGiaKhacInput.focus();
                    return;
                }
            }

            const data = {
                ho_ten: document.getElementById('ho_ten').value.trim(),
                nam_sinh: document.getElementById('nam_sinh').value.trim(),
                dia_chi: document.getElementById('dia_chi').value.trim(),
                chuong_trinh: document.getElementById('chuong_trinh').value,
                quoc_gia: selectedQuocGia, 
                sdt: document.getElementById('sdt').value.trim()
            };

            fetch('/web8s/backend_api/insert.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
            .then(res => res.json())
            .then(result => {
                if (messageDisplay) {
                    if (result.status) {
                        messageDisplay.textContent = '✅ Đăng ký thành công! Chúng tôi sẽ liên hệ sớm.';
                        messageDisplay.style.color = 'green';
                        form.reset();
                        if (quocGiaKhacBox) quocGiaKhacBox.style.display = 'none';
                    } else {
                        messageDisplay.textContent = '❌ Lỗi: ' + result.message;
                        messageDisplay.style.color = 'red';
                    }
                }
            })
            .catch(err => {
                console.error(err);
                if (messageDisplay) {
                    messageDisplay.textContent = '❌ Không kết nối được tới máy chủ.';
                    messageDisplay.style.color = 'red';
                }
            });
        });
    }
});