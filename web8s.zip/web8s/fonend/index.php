<?php
// --- PHẦN 1: KẾT NỐI DATABASE & LẤY CẤU HÌNH TỪ ADMIN ---

// 1. Kết nối Database
include '../backend_api/db_config.php';

$CFG = []; // Khởi tạo mảng cấu hình rỗng

// 2. Lấy dữ liệu cấu hình từ bảng page_settings
if (isset($conn)) {
    $sql_settings = "SELECT * FROM page_settings";
    $result_settings = $conn->query($sql_settings);

    if ($result_settings && $result_settings->num_rows > 0) {
        while($row = $result_settings->fetch_assoc()) {
            $CFG[$row['setting_key']] = $row['setting_value'];
        }
    }
}

// Hàm hỗ trợ lấy giá trị (Nếu không có trong DB thì lấy giá trị mặc định)
function get_val($key, $default = '') {
    global $CFG;
    return !empty($CFG[$key]) ? $CFG[$key] : $default;
}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title><?php echo get_val('site_title', 'Trung Tâm Tư Vấn Du Học & Xuất Khẩu Lao Động'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />

    <style>
        /* === RESET & CƠ BẢN === */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            background: #f4f7fb;
            line-height: 1.6;
            padding-top: 110px;
        }

        /* === TOP BAR === */
        .top-bar {
            background: linear-gradient(to right, #e60000, #ff4d4d);
            color: white;
            padding: 0 50px;
            height: 40px;
            display: flex;
            justify-content: center;
            gap: 30px;
            align-items: center;
            font-size: 14px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 2000;
        }

        .top-bar a {
            background: white;
            color: #e60000;
            padding: 4px 15px;
            text-decoration: none;
            border-radius: 15px;
            font-weight: bold;
            font-size: 12px;
            transition: 0.3s;
        }

        .top-bar a:hover {
            background: #ffe6e6;
        }

        /* === NAVIGATION === */
        nav {
            background: #0f75bd;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 10%;
            position: fixed;
            top: 40px;
            left: 0;
            width: 100%;
            z-index: 1999;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .nav-logo {
            display: flex;
            align-items: center;
            background: white;
            padding: 5px 15px;
            border-radius: 5px;
            height: 44px;
            text-decoration: none;
        }

        .nav-logo img {
            height: 100%;
            width: auto;
            object-fit: contain;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            position: relative;
        }

        nav ul li a {
            color: rgb(255, 255, 255);
            padding: 0 15px;
            line-height: 60px;
            display: block;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            font-size: 15px;
        }

        nav ul li a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        /* === SUBMENU === */
        .submenu,
        .nested {
            display: none;
            position: absolute;
            background: white;
            top: 60px;
            left: 0;
            min-width: 200px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            border-radius: 0 0 5px 5px;
            padding: 0;
            list-style: none;
        }

        .submenu li,
        .nested li {
            margin: 0;
            width: 100%;
        }

        .submenu a,
        .nested a {
            color: #333 !important;
            line-height: 1.5;
            padding: 10px 20px;
            border-bottom: 1px solid #eee;
            display: block;
        }

        .submenu a:hover,
        .nested a:hover {
            background: #f4f7fb;
            color: #0f75bd !important;
        }

        .arrow {
            font-size: 10px;
            margin-left: 5px;
        }

        /* === HERO BANNER & SLIDER === */
        .hero-banner {
            width: 100%;
            overflow: hidden;
        }

        .hero-banner img {
            width: 100%;
            height: auto;
            display: block;
            object-fit: cover;
        }

        .banner {
            background: #003366;
            color: white;
            text-align: center;
            padding: 15px;
            font-weight: bold;
            font-size: 18px;
            text-transform: uppercase;
        }

        .two-column-section {
            display: flex;
            max-width: 1200px;
            margin: 30px auto;
            gap: 30px;
            padding: 0 20px;
        }

        .left-slider {
            flex: 6;
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .slider-container {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
        }

        .slider {
            display: flex;
            transition: transform 0.5s ease-in-out;
            height: 100%;
        }

        .slider img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            flex-shrink: 0;
        }

        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border-radius: 50%;
            padding: 10px;
            cursor: pointer;
            user-select: none;
            z-index: 10;
        }

        .prev {
            left: 10px;
        }

        .next {
            right: 10px;
        }

        .slider-btn:hover {
            background: #ff6600;
        }

        .right-text {
            flex: 4;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .right-text h2 {
            color: #0f75bd;
            margin-bottom: 10px;
            font-size: 20px;
            border-bottom: 2px solid #eee;
            padding-bottom: 5px;
        }

        .right-text p {
            margin-bottom: 20px;
            color: #555;
            font-size: 15px;
            text-align: justify;
        }

        /* === FORM === */
        .form-container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-top: 5px solid #ff6600;
        }

        .form-container h3 {
            text-align: center;
            color: #ff6600;
            margin-bottom: 20px;
            font-size: 24px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            margin-top: 15px;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        /* [QUAN TRỌNG] CSS để tự động viết hoa chữ cái đầu (nhìn thấy) mà không cần JS */
        #ho_ten {
            text-transform: capitalize;
        }

        button[type="submit"] {
            width: 100%;
            margin-top: 25px;
            padding: 12px;
            background: #ff6600;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button[type="submit"]:hover {
            background: #e65c00;
        }

        #message {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .two-column-section {
                flex-direction: column;
            }

            .top-bar {
                padding: 5px 10px;
                flex-direction: column;
                height: auto;
                padding-bottom: 10px;
                gap: 10px;
            }

            nav {
                top: 60px;
                padding: 0 10px;
            }

            body {
                padding-top: 110px;
            }

            .slider-container {
                height: 250px;
            }

            nav ul li a {
                padding: 0 10px;
                font-size: 14px;
            }
        }
    </style>
</head>

<body>

    <div class="top-bar">
        <span>📞 Hotline: <?php echo get_val('hotline', '0822.314.555'); ?></span>
        <a href="#dangky">Đăng ký tìm hiểu</a>
    </div>

    <nav>
        <a href="index.php" class="nav-logo">
            <img src="https://www.icogroup.vn/vnt_upload/company/Logo_icogroup4x.png" alt="ICOGroup Logo">
        </a>

        <ul>
            <li><a href="index.php">Trang chủ</a></li>

            <li>
                <a onclick="toggleMenu('duhocMenu','arrow1')">Du học <span id="arrow1" class="arrow">▶</span></a>
                <ul id="duhocMenu" class="submenu">
                    <li><a href="duc.php">Du học Đức</a></li>
                    <li><a href="nhat.php">Du học Nhật</a></li>
                    <li><a href="han.php">Du học Hàn Quốc</a></li>
                </ul>
            </li>

            <li>
                <a onclick="toggleNested(event,'xkldNested','arrowXKLD')">Xuất khẩu lao động <span id="arrowXKLD"
                        class="arrow">▶</span></a>
                <ul id="xkldNested" class="submenu">
                    <li><a href="xkldjp.php">Nhật Bản</a></li>
                    <li><a href="xkldhan.php">Hàn Quốc</a></li>
                    <li><a href="xklddailoan.php">Đài Loan</a></li>
                    <li><a href="xkldchauau.php">Châu Âu</a></li>
                </ul>
            </li>

            <li><a href="hoatdong.php">Hoạt động</a></li>
            <li><a href="lienhe.php">Liên hệ</a></li>
            <li><a href="#dangky" style="font-weight:bold; color: #ffcc00;">Đăng ký</a></li>
        </ul>
    </nav>

    <div class="hero-banner">
        <img src="<?php echo get_val('home_banner_img', 'https://icogroup.vn/vnt_upload/weblink/banner_trang_chu_01.jpg'); ?>" alt="Banner Trang Chủ">
    </div>
    
    <div class="banner">
        <?php echo get_val('home_banner_title', 'TƯ VẤN DU HỌC & XUẤT KHẨU LAO ĐỘNG'); ?>
    </div>

    <section class="two-column-section">
        <div class="left-slider">
            <div class="slider-container">
                <span class="slider-btn prev material-symbols-outlined">chevron_left</span>
                <div class="slider">
                    <img src="<?php echo get_val('home_banner_img', 'https://icogroup.vn/vnt_upload/weblink/banner_trang_chu_01.jpg'); ?>" alt="Slide 1">
                    
                    <img src="<?php echo get_val('home_banner2_img', 'https://icogroup.vn/vnt_upload/weblink/banner_chu_04.jpg'); ?>" alt="Slide 2">
                    
                    <img src="<?php echo get_val('home_banner3_img', 'https://www.icogroup.vn/vnt_upload/news/02_2025/ICOGROUP_TUYEN_DUNG_23.jpg'); ?>" alt="Slide 3">
                </div>
                <span class="slider-btn next material-symbols-outlined">chevron_right</span>
            </div>
        </div>

        <div class="right-text">
            <h2><?php echo get_val('home_banner_title', 'Chương trình Du học'); ?></h2>
            <p><?php echo get_val('home_banner_desc', 'Hỗ trợ các bạn trẻ đến Nhật Bản – Hàn Quốc – Đài Loan – Đức một cách dễ dàng và uy tín nhất.'); ?></p>

            <h2><?php echo get_val('home_banner2_title', 'Chương trình Xuất Khẩu Lao Động'); ?></h2>
            <p><?php echo get_val('home_banner2_desc', 'Cam kết việc làm ổn định, lương cao, hợp đồng rõ ràng tại Nhật – Hàn – Đài Loan – Châu Âu.'); ?></p>

            <h2><?php echo get_val('home_banner3_title', 'Hoạt động nổi bật'); ?></h2>
            <p><?php echo get_val('home_banner3_desc', 'Các buổi hội thảo, hướng nghiệp, định hướng hồ sơ và hoạt động ngoại khóa thường xuyên giúp học viên tự tin hội nhập quốc tế.'); ?></p>
        </div>
    </section>

    <div class="form-container" id="dangky">
        <h3>ĐĂNG KÝ TƯ VẤN NHANH</h3>
        <form id="userRegistrationForm">
            <label>Họ và Tên:</label>
            <input type="text" name="ho_ten" id="ho_ten" required placeholder="Nhập họ tên của bạn...">

            <label>Năm Sinh:</label>
            <input type="text" name="nam_sinh" id="nam_sinh" required maxlength="4" placeholder="Ví dụ: 2005">

            <label>Địa Chỉ:</label>
            <input type="text" name="dia_chi" id="dia_chi" required placeholder="Tỉnh/Thành phố...">

            <label>Chương Trình Quan Tâm:</label>
            <select name="chuong_trinh" id="chuong_trinh" required>
                <option value="Du học Nhật Bản">Du học Nhật Bản</option>
                <option value="Du học Hàn Quốc">Du học Hàn Quốc</option>
                <option value="Xuất khẩu lao động">Xuất khẩu lao động</option>
                <option value="Đào tạo ngoại ngữ">Đào tạo ngoại ngữ</option>
            </select>

            <label>Quốc Gia Muốn Đến:</label>
            <select name="quoc_gia" id="quoc_gia">
                <option value="Nhật Bản">Nhật Bản</option>
                <option value="Hàn Quốc">Hàn Quốc</option>
                <option value="Đài Loan">Đài Loan</option>
                <option value="Đức">Đức</option>
                <option value="Khác">Khác</option>
            </select>

            <div id="quoc_gia_khac_box" style="display:none;">
                <label>Nhập quốc gia khác:</label>
                <input type="text" id="quoc_gia_khac">
            </div>

            <label>Số Điện Thoại:</label>
            <input type="tel" name="sdt" id="sdt" required maxlength="11" pattern="[0-9]{9,11}"
                placeholder="Nhập số điện thoại...">

            <button type="submit" class="form-submit">GỬI THÔNG TIN</button>
            <p id="message"></p>
        </form>
    </div>

    <section style="background:#002b6f; color:white; padding:40px 20px; margin-top:40px;">
        <div style="max-width:1100px; margin:auto; display:flex; gap:30px; align-items:center; flex-wrap:wrap;">
            <div style="flex:1; min-width:260px;">
                <h2 style="margin-top:0;">CÔNG TY CỔ PHẦN NHÂN LỰC QUỐC TẾ ICO</h2>
                <p><strong>📌 Địa chỉ:</strong> <?php echo get_val('contact_address', 'Số 360, đường Phan Đình Phùng, Tỉnh Thái Nguyên'); ?></p>
                <p><strong>📞 Hotline:</strong> <?php echo get_val('hotline', '0822.314.555'); ?></p>
                <p><strong>📧 Email:</strong> <?php echo get_val('email', 'contact@icogroup.vn'); ?></p>
                <p><strong>🌐 Liên hệ:</strong> Facebook | Zalo | Website</p>
            </div>
            <div style="flex:1; min-width:300px;">
               <?php echo get_val('contact_map', '<iframe src="https://www.google.com/maps/embed?pb=..." width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>'); ?>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            /* ========================== */
            /* 1. XỬ LÝ SLIDER (BANNER)   */
            /* ========================== */
            const slider = document.querySelector(".slider");
            const images = document.querySelectorAll(".slider img");
            const nextBtn = document.querySelector(".next");
            const prevBtn = document.querySelector(".prev");

            if (slider && images.length > 0) {
                let index = 0;
                let slideInterval;

                const updateSlider = () => {
                    slider.style.transform = `translateX(-${index * 100}%)`;
                };

                const startSlideTimer = () => {
                    if (slideInterval) clearInterval(slideInterval);
                    slideInterval = setInterval(() => {
                        index++;
                        if (index >= images.length) index = 0;
                        updateSlider();
                    }, 4000);
                };

                if (nextBtn) {
                    nextBtn.onclick = () => {
                        index++;
                        if (index >= images.length) index = 0;
                        updateSlider();
                        startSlideTimer();
                    };
                }

                if (prevBtn) {
                    prevBtn.onclick = () => {
                        index--;
                        if (index < 0) index = images.length - 1;
                        updateSlider();
                        startSlideTimer();
                    };
                }
                startSlideTimer();
            }

            /* ========================== */
            /* 2. XỬ LÝ MENU DROPDOWN     */
            /* ========================== */
            window.toggleMenu = function (id, arrowId) {
                document.querySelectorAll(".submenu").forEach(m => {
                    if (m.id !== id) m.style.display = "none";
                });
                document.querySelectorAll(".arrow").forEach(a => {
                    if (a.id !== arrowId) a.textContent = "▶";
                });

                let menu = document.getElementById(id);
                let arrow = document.getElementById(arrowId);

                if (menu.style.display === "block") {
                    menu.style.display = "none";
                    arrow.textContent = "▶";
                } else {
                    menu.style.display = "block";
                    arrow.textContent = "▼";
                }
            };

            window.toggleNested = function (event, nestedId, arrowId) {
                toggleMenu(nestedId, arrowId);
            };

            window.onclick = function (event) {
                if (!event.target.closest('li')) {
                    document.querySelectorAll(".submenu").forEach(m => m.style.display = "none");
                    document.querySelectorAll(".arrow").forEach(a => a.textContent = "▶");
                }
            };

            /* ========================== */
            /* 3. HIỆN Ô NHẬP QUỐC GIA    */
            /* ========================== */
            const quocGiaSelect = document.getElementById("quoc_gia");
            const quocGiaKhacBox = document.getElementById("quoc_gia_khac_box");

            if (quocGiaSelect && quocGiaKhacBox) {
                quocGiaSelect.addEventListener("change", function () {
                    quocGiaKhacBox.style.display = (this.value === "Khác") ? "block" : "none";
                });
            }

            /* ========================== */
            /* 4. VALIDATE DỮ LIỆU        */
            /* ========================== */
            const onlyNumberInputs = [document.getElementById("nam_sinh"), document.getElementById("sdt")];
            onlyNumberInputs.forEach(input => {
                if (input) {
                    input.addEventListener("input", function () {
                        this.value = this.value.replace(/[^0-9]/g, "");
                    });
                }
            });

            /* ========================== */
            /* 5. GỬI FORM (AJAX)         */
            /* ========================== */
            const form = document.getElementById('userRegistrationForm');
            if (form) {
                form.addEventListener('submit', async function (event) {
                    event.preventDefault(); // Chặn load lại trang

                    const messageDisplay = document.getElementById('message');
                    const btn = document.querySelector('.form-submit');
                    const oldText = btn.innerText;

                    // Xử lý Logic Quốc Gia
                    let selectedQuocGia = document.getElementById('quoc_gia').value;
                    const quocGiaKhacInput = document.getElementById('quoc_gia_khac');

                    if (selectedQuocGia === "Khác") {
                        const customVal = quocGiaKhacInput ? quocGiaKhacInput.value.trim() : "";
                        if (customVal !== "") {
                            selectedQuocGia = customVal;
                        } else {
                            messageDisplay.textContent = '❌ Vui lòng nhập tên quốc gia mong muốn.';
                            messageDisplay.style.color = 'red';
                            if (quocGiaKhacInput) quocGiaKhacInput.focus();
                            return;
                        }
                    }

                    // 1. Lấy dữ liệu từ ô nhập
                    const data = {
                        ho_ten: document.getElementById('ho_ten').value.trim(),
                        nam_sinh: document.getElementById('nam_sinh').value.trim(),
                        dia_chi: document.getElementById('dia_chi').value.trim(),
                        chuong_trinh: document.getElementById('chuong_trinh').value,
                        quoc_gia: selectedQuocGia,
                        sdt: document.getElementById('sdt').value.trim()
                    };

                    // 2. Hiệu ứng đang gửi
                    btn.innerText = "⏳ Đang gửi...";
                    btn.disabled = true;
                    messageDisplay.textContent = '';

                    try {
                        // 3. Gửi sang Backend (Sửa đúng đường dẫn file submit_form.php)
                        // LƯU Ý: Đã đổi đường dẫn về submit_form.php như các hướng dẫn trước
                        let response = await fetch('../backend_api/submit_form.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });

                        let result = await response.json();

                        // 4. Thông báo kết quả
                        if (result.status) {
                            messageDisplay.textContent = '✅ ' + result.message;
                            messageDisplay.style.color = 'green';
                            form.reset(); // Xóa trắng form
                            if (quocGiaKhacBox) quocGiaKhacBox.style.display = 'none';
                        } else {
                            messageDisplay.textContent = '❌ ' + result.message;
                            messageDisplay.style.color = 'red';
                        }
                    } catch (error) {
                        messageDisplay.textContent = '❌ Lỗi kết nối Server! Vui lòng thử lại.';
                        messageDisplay.style.color = 'red';
                        console.error(error);
                    } finally {
                        btn.innerText = oldText;
                        btn.disabled = false;
                    }
                });
            }
        });
    </script>

</body>

</html>